def main():
    print("Hello from buddy-tony-stark-demo!")


if __name__ == "__main__":
    main()
